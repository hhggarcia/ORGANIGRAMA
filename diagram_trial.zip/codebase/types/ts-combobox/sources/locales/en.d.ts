declare const _default: {
    notFound: string;
    selectAll: string;
    unselectAll: string;
    selectedItems: string;
    createItem: string;
};
export default _default;
