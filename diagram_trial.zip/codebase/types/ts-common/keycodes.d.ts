export declare const KEY_CODES: {
    BACKSPACE: number;
    ENTER: number;
    ESC: number;
    DOWN_ARROW: number;
    UP_ARROW: number;
    LEFT_ARROW: number;
    RIGHT_ARROW: number;
};
