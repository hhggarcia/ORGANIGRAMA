declare const en: {
    cancel: string;
    select: string;
    rightClickToDelete: string;
    customColors: string;
    addNewColor: string;
};
export default en;
