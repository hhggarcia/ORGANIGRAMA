import { IShapeToolbarConfig } from "../../../ts-diagram";
export declare function getOrgShapeToolbar(locale: any): IShapeToolbarConfig[];
export declare function getMindmapShapeToolbar(locale: any): IShapeToolbarConfig[];
export declare function getDefaultShapeToolbar(locale: any): IShapeToolbarConfig[];
