export declare function getIcon(name: string, css?: string, w?: number, h?: number): any;
export declare function addIcon(): any;
export declare function removeIcon(): any;
