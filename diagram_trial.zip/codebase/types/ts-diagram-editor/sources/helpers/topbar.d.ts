export declare function topbar(editor: any): any;
