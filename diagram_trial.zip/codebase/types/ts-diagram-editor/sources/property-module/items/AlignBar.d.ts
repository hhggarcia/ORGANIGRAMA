import { Text } from "./Text";
export declare class AlignBar extends Text {
    constructor(config: any, ev: any);
    toVDOM(): any;
}
