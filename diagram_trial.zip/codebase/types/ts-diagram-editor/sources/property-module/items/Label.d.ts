import { Text } from "./Text";
export declare class Label extends Text {
    toVDOM(): any;
}
