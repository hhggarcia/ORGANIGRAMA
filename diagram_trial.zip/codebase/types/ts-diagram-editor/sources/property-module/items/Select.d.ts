import { Text } from "./Text";
export declare class Select extends Text {
    toVDOM(): any;
    private _getOptions;
}
