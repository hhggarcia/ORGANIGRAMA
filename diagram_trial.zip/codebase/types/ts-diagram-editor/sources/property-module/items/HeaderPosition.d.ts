import { Text } from "./Text";
export declare class HeaderPosition extends Text {
    constructor(config: any, events: any);
    toVDOM(): any;
}
