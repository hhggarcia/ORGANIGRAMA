import { Text } from "./Text";
export declare class Enable extends Text {
    constructor(config: any, events: any);
    toVDOM(): any;
}
