export declare function getIconGroup(handler: any, id: string, icons: any[], selectedId?: string, checkboxMode?: boolean): any;
export declare function getSelect(handler: any, id: string, opt: any[], selectedId: string): any[];
