export declare function validate(val: any, rule: any): boolean;
