import { ShapesCollection } from "../ShapesCollection";
export declare function setHeaderColor(data: ShapesCollection): void;
