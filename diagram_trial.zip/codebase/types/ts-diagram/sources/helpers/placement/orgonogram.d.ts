import { ShapesCollection } from "../../ShapesCollection";
import { IDiagramConfig } from "../../types";
export declare function placeOrgonogram(data: ShapesCollection, config: IDiagramConfig): void;
