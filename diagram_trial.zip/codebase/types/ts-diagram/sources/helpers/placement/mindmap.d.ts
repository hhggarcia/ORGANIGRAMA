import { ShapesCollection } from "../../ShapesCollection";
import { IDiagramConfig } from "../../types";
export declare function placeMindmap(data: ShapesCollection, config: IDiagramConfig): void;
