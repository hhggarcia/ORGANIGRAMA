import { IGraph } from "../types";
export declare function decompose(g: IGraph): IGraph[];
