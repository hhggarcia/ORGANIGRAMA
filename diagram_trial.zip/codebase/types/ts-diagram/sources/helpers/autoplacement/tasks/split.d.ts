import { IGraph, ISubGraph } from "../types";
export declare function split(g: IGraph): ISubGraph[];
