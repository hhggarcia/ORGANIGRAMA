import { IGraph } from "../types";
export declare function compose(many: IGraph[], cfg: any): IGraph;
