import { IGraph } from "../types";
export default class Radial {
    layout(g: IGraph, config: any): IGraph;
}
