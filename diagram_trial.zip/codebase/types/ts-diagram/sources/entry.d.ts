import "../../styles/diagram.scss";
import "../../styles/menu.scss";
export { awaitRedraw } from "../../ts-common/dom";
export { Diagram } from "./Diagram";
export declare const i18n: any;
