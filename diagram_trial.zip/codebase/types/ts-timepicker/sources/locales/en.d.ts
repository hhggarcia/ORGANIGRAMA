declare const locale: {
    hours: string;
    minutes: string;
    save: string;
};
export default locale;
