export as namespace dhx;

export * from "./types/ts-diagram/sources/entry_editor";
