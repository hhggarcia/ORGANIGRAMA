/*
@license

dhtmlxDiagram v.5.0.3 Professional
This software is covered by Evaluation License. Usage without proper license is prohibited.

(c) XB Software.
*/


Useful links
-------------

- Online  documentation
	https://docs.dhtmlx.com/